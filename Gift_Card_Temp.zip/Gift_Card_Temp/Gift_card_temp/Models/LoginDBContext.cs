﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Gift_card_temp.Models
{
    public class LoginDBContext : DbContext
    {
        public LoginDBContext()
            : base("GiftcardDBEntities") { }
        public DbSet userAccount { get; set; }
    }
}